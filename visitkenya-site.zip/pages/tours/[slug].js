import { useRouter } from 'next/router'
import Head from 'next/head'

export default function TourPage() {
  const router = useRouter()
  const { slug } = router.query

  return (
    <>
      <Head>
        <title>{slug} Safari</title>
      </Head>
      <header>
        <h1>{slug.replace('-', ' ')} Safari</h1>
      </header>
      <main style={{ padding: '1rem' }}>
        <p>Details about the {slug.replace('-', ' ')} Safari will appear here.</p>
      </main>
    </>
  )
}
