import Link from 'next/link'
import Head from 'next/head'

export default function Home() {
  return (
    <>
      <Head>
        <title>Visit Kenya - Safari Tours</title>
      </Head>
      <header>
        <h1>Visit Kenya</h1>
        <p>Unforgettable Safari Experiences</p>
      </header>
      <main style={{ padding: '1rem' }}>
        <h2>Explore Our Tours</h2>
        <ul>
          <li><Link href="/tours/masai-mara">Masai Mara Safari</Link></li>
          <li><Link href="/tours/amboseli">Amboseli Safari</Link></li>
        </ul>
        <p>
          <Link href="/booking">Book a Tour</Link>
        </p>
      </main>
      <footer>
        &copy; {new Date().getFullYear()} Visit Kenya
      </footer>
    </>
  )
}
