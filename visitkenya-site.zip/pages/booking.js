import Head from 'next/head'

export default function Booking() {
  return (
    <>
      <Head>
        <title>Book a Safari Tour</title>
      </Head>
      <header>
        <h1>Book Your Safari</h1>
      </header>
      <main style={{ padding: '1rem' }}>
        <form>
          <label>Name: <input type="text" name="name" required /></label><br /><br />
          <label>Email: <input type="email" name="email" required /></label><br /><br />
          <label>Tour:
            <select name="tour">
              <option>Masai Mara</option>
              <option>Amboseli</option>
            </select>
          </label><br /><br />
          <button type="submit">Submit</button>
        </form>
      </main>
    </>
  )
}
